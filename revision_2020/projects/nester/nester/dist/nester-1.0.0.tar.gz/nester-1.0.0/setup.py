from distutils.core import setup

setup(
    name = 'nester',
    version='1.0.0',
    py_modules=['nester'],
    author='mariuszpudzianowski',
    author_email='sp1koszalin@o2.pl',
    url= 'http://www.headfirstlabs.com',
    description='A simple printer of nested lists.',
)